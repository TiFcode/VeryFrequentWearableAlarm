package ro.tif.veryfrequentwearablealarm
import android.app.Service
import android.content.Intent
import android.os.*

class VibrationService : Service() {

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Schedule vibrations to occur at regular intervals
        val intervalInMilliseconds: Long = 10  * 1000 // 10 seconds in ms
        val handler = Handler(Looper.getMainLooper())
        val vibrator: Vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
        val vibrationEffect1 = VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE)
        val runnable = object : Runnable {
            override fun run() {
                // Vibrate the watch
                vibrator.vibrate(vibrationEffect1)
                // Schedule the next vibration
                handler.postDelayed(this, intervalInMilliseconds)
            }
        }
        handler.postDelayed(runnable, intervalInMilliseconds)
        return START_STICKY
    }
    override fun onBind(intent: Intent): IBinder? {
        return null
    }
}
