package ro.tif.veryfrequentwearablealarm

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import ro.tif.veryfrequentwearablealarm.databinding.ActivityMainBinding
import android.os.Vibrator
import android.os.VibrationEffect

class MainActivity : Activity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Start the VibrationService
        val intent = Intent(this, VibrationService::class.java)
        startForegroundService(intent)

    }
}